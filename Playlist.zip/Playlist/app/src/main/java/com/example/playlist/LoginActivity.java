package com.example.playlist;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button submitButton;

    private static final String CORRECT_USERNAME = "Alan";
    private static final String CORRECT_PASSWORD = "123";
    private int loginAttempts = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        startActivity(intent);
        finish();

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        submitButton = findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                if (isValidUser(username, password)) {
                    Toast.makeText(LoginActivity.this, "Redirecting...", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent);
                    finish();

                } else {
                    loginAttempts--;

                    if (loginAttempts > 0) {
                        String message = "Wrong Credentials. " + loginAttempts + " attempts remaining.";
                        Toast.makeText(LoginActivity.this, message, Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(LoginActivity.this, "No attempts left. Account locked.", Toast.LENGTH_LONG).show();
                        submitButton.setEnabled(false);
                    }
                }
            }
        });
    }

    private boolean isValidUser(String username, String password) {
        return username.equals(CORRECT_USERNAME) && password.equals(CORRECT_PASSWORD);
    }
}

