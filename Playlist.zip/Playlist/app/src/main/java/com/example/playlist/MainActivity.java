package com.example.playlist;

import androidx.appcompat.app.AppCompatActivity;
import android.os.AsyncTask;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.app.AlertDialog;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private ListView playList;
    private List<ItemObject> parsedObject = new ArrayList<>(); // Moving this to class level for wider access

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playList = findViewById(R.id.listView);
        Button showAnalyticsButton = findViewById(R.id.statsButton);

        showAnalyticsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                displayStats(parsedObject);
            }
        });

        new AsyncDataClass().execute();
    }

    private void displayStats(List<ItemObject> items) {
        int count = items.size();

        ItemObject mostExpensiveCD = null;
        for (ItemObject item : items) {
            if (mostExpensiveCD == null || Double.parseDouble(item.getPrice()) > Double.parseDouble(mostExpensiveCD.getPrice())) {
                mostExpensiveCD = item;
            }
        }

        StringBuilder countries = new StringBuilder();
        for (ItemObject item : items) {
            countries.append(item.getCountry()).append("\n");
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Playlist Analytics");
        builder.setMessage(
                "Number of titles: " + count +
                        "\nMost expensive CD: " + mostExpensiveCD.getTitle() + " - $" + mostExpensiveCD.getPrice() +
                        "\nCountries of origin:\n" + countries
        );
        builder.setNeutralButton("Close", null);
        builder.show();
    }

    private class AsyncDataClass extends AsyncTask<String, Void,
            String> {
        HttpURLConnection urlConnection;
        @Override
        protected String doInBackground(String...params ) {

            StringBuilder jsonResult = new StringBuilder();

            try {

                URL url = new
                        URL("http://www.papademas.net:81/cd_catalog.json");
                urlConnection = (HttpURLConnection)
                        url.openConnection();
                InputStream in = new
                        BufferedInputStream(urlConnection.getInputStream());

                BufferedReader reader = new BufferedReader(new
                        InputStreamReader(in));
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonResult.append(line);
                }
                System.out.println("Returned Json url object " +
                        jsonResult.toString());

            } catch (Exception e) {System.out.println("Err: " + e);}
            finally {
                urlConnection.disconnect();
            }
            return jsonResult.toString();
        }

        @Override
        protected void onPreExecute() {  }

        @Override
        protected void onPostExecute(String result) {

            System.out.println("Result on post execute: " + result);
            parsedObject = returnParsedJsonObject(result);

            CustomAdapter jsonCustomAdapter = new
                    CustomAdapter(MainActivity.this, parsedObject);
            playList.setAdapter(jsonCustomAdapter);
        }

    } //end AsyncDataClass class

    private List<ItemObject> returnParsedJsonObject(String result){

        List<ItemObject> jsonObject = new ArrayList<ItemObject>();
        JSONObject resultObject = null;
        JSONArray jsonArray = null;
        ItemObject newItemObject = null; //interior object holder

        try {
            resultObject = new JSONObject(result);
            System.out.println("Preparsed JSON object " +
                    resultObject.toString());
            // set up json Array to be parsed
            jsonArray = resultObject.optJSONArray("Bluesy_Music");
        } catch (JSONException e) { e.printStackTrace(); }
        for(int i = 0; i < jsonArray.length(); i++){
            JSONObject jsonChildNode = null;
            try {
                jsonChildNode = jsonArray.getJSONObject(i);
                //get all data from stream
                String songSold = jsonChildNode.getString("SOLD");
                String songTitle = jsonChildNode.getString("TITLE");
                String songArtist =
                        jsonChildNode.getString("ARTIST");
                String songCountry =
                        jsonChildNode.getString("COUNTRY");
                String songCompany =
                        jsonChildNode.getString("COMPANY");
                String songPrice = jsonChildNode.getString("PRICE");
                String songYear = jsonChildNode.getString("YEAR");
                newItemObject = new ItemObject(songSold, songTitle, songArtist, songCountry, songCompany, songPrice, songYear);
                jsonObject.add(newItemObject);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return jsonObject;
    }

}